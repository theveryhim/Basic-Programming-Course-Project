#include <iostream>
using namespace std;
int main()
{cout<<"khkjh";
    return 0;
}
